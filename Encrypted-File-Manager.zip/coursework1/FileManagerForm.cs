﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace сoursework
{
    public partial class FileManagerForm : Form
    {
        private string FolderPath = @"C:\Users\k0tsu\Desktop\coursework\Files\";
        private string User = @"C:\Users\k0tsu\Desktop\coursework\logged.txt";
        private string Book = @"C:\Users\k0tsu\Desktop\coursework\us_book.txt";
        private string SelectedFilesPath;
        public List<string> FilesPath = new List<string>();
        int Do;
        string Login;
        int LevelAccess;
        private EditForm FormEdit;
        
        public FileManagerForm()
        {
            InitializeComponent();

            FilesListBox.Items.Clear();
            using (StreamReader StreamReader = new StreamReader(User))
            {
                string Line = StreamReader.ReadLine();
                string[] LoginUser = Line.Split(',');
                Login = LoginUser[0];
                LevelAccess = Convert.ToInt32(LoginUser[1]);

                string[] Files = Directory.GetFiles(@"C:\Users\k0tsu\Desktop\coursework\Files\1\");
                foreach (string File in Files)
                {
                    FilesListBox.Items.Add(Path.GetFileName(File));
                    FilesPath.Add(File);
                }
                if (LevelAccess >= 2)
                {
                    Files = Directory.GetFiles(@"C:\Users\k0tsu\Desktop\coursework\Files\2\");
                    foreach (string File in Files)
                    {
                        FilesListBox.Items.Add(Path.GetFileName(File));
                        FilesPath.Add(File);
                    }
                }
                if (LevelAccess >= 3)
                {
                    Files = Directory.GetFiles(@"C:\Users\k0tsu\Desktop\coursework\Files\3\");
                    foreach (string File in Files)
                    {
                        FilesListBox.Items.Add(Path.GetFileName(File));
                        FilesPath.Add(File);
                    }
                }
                if (LevelAccess < 3)
                {
                    CreateButton.Visible = false;
                    DeleteButton.Visible = false;
                }
                if (LevelAccess < 2)
                {
                    EditButton.Visible = false;
                }
            }
        }
        
        public void ShowHide()
        {
            this.Show();
        }

        private void FilesForm_Load(object sender, EventArgs e)
        {

        }

        private void FilesListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (FilesListBox.SelectedIndex != -1)
            {
                foreach (string File in FilesPath)
                {
                    if (File.Contains(FilesListBox.SelectedItem.ToString()))
                    {
                        SelectedFilesPath = File;
                        break;
                    }
                }
            }
        }

        public void Checker()
        {
            Do += 1;
            if (Do % 10 == 0)
            {
                this.Enabled = false;
                MessageBox.Show("Пройдіть автентифікацію для продовження роботи.");
                FormulaForm FormulaForm = new FormulaForm(this);
                FormulaForm.Show();
            }
        }

        private void CreateButton_Click(object sender, EventArgs e)
        {
            Checker();
            CreateForm CreateForm = new CreateForm(this);
            CreateForm.Show();
            this.Hide();
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            Checker();
            if (FilesListBox.SelectedIndex != -1)
            {
                File.Delete(SelectedFilesPath);
                FilesListBox.Items.RemoveAt(FilesListBox.SelectedIndex);
                MessageBox.Show("Видалено.");
                using (StreamWriter StreamWriter = new StreamWriter(Book, true))
                {
                    StreamWriter.WriteLine(Login + ", " + DateTime.Now + ", Delete file");
                }
            }
            else
            {
                MessageBox.Show("Виберіть файл для видалення.");
            }
        }

        private void RefreshButton_Click(object sender, EventArgs e)
        {
            FilesListBox.Items.Clear();
            using (StreamReader StreamReader = new StreamReader(User))
            {
                string Line = StreamReader.ReadLine();
                string[] Login = Line.Split(',');
                this.Login = Login[0];
                LevelAccess = Convert.ToInt32(Login[1]);

                string[] Files = Directory.GetFiles(@"C:\Users\k0tsu\Desktop\coursework\Files\1\");
                foreach (string File in Files)
                {
                    FilesListBox.Items.Add(Path.GetFileName(File));
                    FilesPath.Add(File);
                }
                if (LevelAccess >= 2)
                {
                    Files = Directory.GetFiles(@"C:\Users\k0tsu\Desktop\coursework\Files\2\");
                    foreach (string File in Files)
                    {
                        FilesListBox.Items.Add(Path.GetFileName(File));
                        FilesPath.Add(File);
                    }
                }
                if (LevelAccess >= 3)
                {
                    Files = Directory.GetFiles(@"C:\Users\k0tsu\Desktop\coursework\Files\3\");
                    foreach (string File in Files)
                    {
                        FilesListBox.Items.Add(Path.GetFileName(File));
                        FilesPath.Add(File);
                    }
                }
                if (LevelAccess < 3)
                {
                    CreateButton.Visible = false;
                    DeleteButton.Visible = false;
                }
                if (LevelAccess < 2)
                {
                    EditButton.Visible = false;
                }
            }
        }

        private void ReadButton_Click(object sender, EventArgs e)
        {
            Checker();
            string[] Content = File.ReadAllLines(SelectedFilesPath);
            using (StreamWriter StreamWriter = new StreamWriter(@"C:\Users\k0tsu\Desktop\coursework\foropen.txt"))
            {
                StreamWriter.WriteLine("");
                foreach (string Line in Content)
                {
                    StreamWriter.WriteLine(Line);
                }
            }
            OpenForm OpenForm = new OpenForm(this);
            OpenForm.Show();
            this.Hide();
        }

        private void EditButton_Click(object sender, EventArgs e)
        {
            Checker();
            string[] Content = File.ReadAllLines(SelectedFilesPath);
            using (StreamWriter StreamWriter = new StreamWriter(@"C:\Users\k0tsu\Desktop\coursework\foropen.txt"))
            {
                StreamWriter.WriteLine("");
                foreach (string Line in Content)
                {
                    StreamWriter.WriteLine(Line);
                }
            }
            EditForm EditForm = new EditForm(SelectedFilesPath, this);
            EditForm.Show();
            this.Hide();
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
            Authorization Authorization = new Authorization();
            Authorization.Show();
        }

        private void DontWorkButton_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
    }
}
