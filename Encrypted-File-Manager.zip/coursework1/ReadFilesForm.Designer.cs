﻿namespace сoursework
{
    partial class OpenForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CloseButton = new System.Windows.Forms.Button();
            this.ReadRichTextBox = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // OpenBtn
            // 
            this.CloseButton.Location = new System.Drawing.Point(397, 324);
            this.CloseButton.Name = "OpenBtn";
            this.CloseButton.Size = new System.Drawing.Size(75, 25);
            this.CloseButton.TabIndex = 1;
            this.CloseButton.Text = "Скасувати";
            this.CloseButton.UseVisualStyleBackColor = true;
            this.CloseButton.Click += new System.EventHandler(this.CloseButton_Click);
            // 
            // ReadRichTextBox
            // 
            this.ReadRichTextBox.Location = new System.Drawing.Point(12, 12);
            this.ReadRichTextBox.Name = "ReadRichTextBox";
            this.ReadRichTextBox.Size = new System.Drawing.Size(400, 238);
            this.ReadRichTextBox.TabIndex = 2;
            this.ReadRichTextBox.Text = "";
            this.ReadRichTextBox.TextChanged += new System.EventHandler(this.ReadRichTextBox_TextChanged);
            // 
            // OpenForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 361);
            this.Controls.Add(this.ReadRichTextBox);
            this.Controls.Add(this.CloseButton);
            this.Name = "OpenForm";
            this.Text = "Перегляд файлу";
            this.Load += new System.EventHandler(this.ReadFilesForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox ReadRichTextBox;
        private System.Windows.Forms.Button CloseButton;
        
    }
}