﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace сoursework
{
    public partial class CreateForm : Form
    {
        private string Logged = @"C:\Users\k0tsu\Desktop\coursework\logged.txt";
        private string Book = @"C:\Users\k0tsu\Desktop\coursework\us_book.txt";
        private string Username;
        private string LevelAccess;
        private FileManagerForm FileManagerForm;

        public CreateForm(FileManagerForm FileManagerForm)
        {
            InitializeComponent();
            using (StreamReader StreamReader = new StreamReader(Logged))
            {
                string Line = StreamReader.ReadLine();
                string[] Users = Line.Split(',');
                Username = Users[0];
            }
            this.FileManagerForm = FileManagerForm;
        }

        private void CreateFilesForm_Load(object sender, EventArgs e)
        {

        }

        private static string EncryptString(string plainText, string key)
        {
            using (Aes AesAlgorithm = Aes.Create())
            {
                AesAlgorithm.Key = Encoding.UTF8.GetBytes(key);
                AesAlgorithm.IV = new byte[AesAlgorithm.BlockSize / 8];

                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, AesAlgorithm.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {
                            swEncrypt.Write(plainText);
                        }
                    }

                    return Convert.ToBase64String(msEncrypt.ToArray());
                }
            }
        }

        private void CreateRichTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void CreateButton_Click(object sender, EventArgs e)
        {
            string NewText = CreateRichTextBox.Text;
            CreateRichTextBox.Clear();
            SaveFileDialog SaveFileDialog = new SaveFileDialog();
            SaveFileDialog.Filter = "Text Files (*.txt)|*.txt|All files (*.*)|*.*";
            SaveFileDialog.FilterIndex = 1;
            SaveFileDialog.RestoreDirectory = true;

            if (SaveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string FilePath = SaveFileDialog.FileName;
                string EncryptionKey = File.ReadAllText(@"C:\Users\k0tsu\Desktop\coursework\DESKey.txt");
                using (var StreamWriter = new StreamWriter(FilePath))
                {
                    string EncryptedText = EncryptString(LevelAccess + Environment.NewLine + NewText, EncryptionKey);
                    StreamWriter.WriteLine(EncryptedText);
                }
            }
            using (StreamWriter StreamWriter = new StreamWriter(Book, true))
            {
                StreamWriter.WriteLine(Username + ", " + DateTime.Now + ", Create file");
            }
            FileManagerForm.ShowHide();
            this.Close();
        }
        private void CancelButton_Click(object sender, EventArgs e)
        {
            FileManagerForm.ShowHide();
            this.Close();
        }
    }
}
