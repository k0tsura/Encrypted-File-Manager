﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace сoursework
{
    public partial class EditForm : Form
    {
        string Username;
        private string Logged = @"C:\Users\k0tsu\Desktop\coursework\logged.txt";
        private string Book = @"C:\Users\k0tsu\Desktop\coursework\us_book.txt";
        string EncryptionKey = File.ReadAllText(@"C:\Users\k0tsu\Desktop\coursework\DESKey.txt");
        private FileManagerForm FilesForm;
        string EncryptedText;
        string SelectedFilesPath;

        public EditForm(string SelectedFilesPath, FileManagerForm FilesForm)
        {
            InitializeComponent();
            this.SelectedFilesPath = SelectedFilesPath;
            using (StreamReader StreamReader = new StreamReader(Logged))
            {
                string Line = StreamReader.ReadLine();
                string[] Users = Line.Split(',');
                Username = Users[0];
            }
            this.FilesForm = FilesForm;
            EncryptedText = File.ReadAllText(SelectedFilesPath);
            EditRichTextBox.Text = DecryptString(EncryptedText, EncryptionKey);
        }

        public void DontWordTextBox(string content)
        {
           
        }
        
        private string DecryptString(string cipherText, string key)
        {
            using (Aes AesAlgorithm = Aes.Create())
            {
                AesAlgorithm.Key = Encoding.UTF8.GetBytes(key);
                AesAlgorithm.IV = new byte[AesAlgorithm.BlockSize / 8];

                using (MemoryStream msDecrypt = new MemoryStream(Convert.FromBase64String(cipherText)))
                using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, AesAlgorithm.CreateDecryptor(), CryptoStreamMode.Read))
                using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                {
                    return srDecrypt.ReadToEnd();
                }
            }
        }

        private static string EncryptString(string plainText, string key)
        {
            using (Aes AesAlgorithm = Aes.Create())
            {
                AesAlgorithm.Key = Encoding.UTF8.GetBytes(key);
                AesAlgorithm.IV = new byte[AesAlgorithm.BlockSize / 8];

                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, AesAlgorithm.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {
                            swEncrypt.Write(plainText);
                        }
                    }

                    return Convert.ToBase64String(msEncrypt.ToArray());
                }
            }
        }

        private void FormEdit_Load(object sender, EventArgs e)
        {

        }

        private void EditRichTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void EditButton_Click(object sender, EventArgs e)
        {
            string PlainText = EditRichTextBox.Text;
            string EncryptedText = EncryptString(PlainText, EncryptionKey);
            using (StreamWriter StreamWriter = new StreamWriter(SelectedFilesPath))
            {
                StreamWriter.Write(EncryptedText);
            }
            MessageBox.Show("Змінено.");
            using (StreamWriter StreamWriter = new StreamWriter(Book, true))
            {
                StreamWriter.WriteLine(Username + ", " + DateTime.Now + ", Rewrite file");
            }
            FilesForm.ShowHide();
            this.Close();
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            FilesForm.ShowHide();
            this.Close();
        }

        private void DontWorkTextBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
