﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace сoursework
{
    public partial class FormulaForm : Form
    {
        string x;
        string Answer;
        string Ask = @"C:\Users\k0tsu\Desktop\coursework\ask.txt";
        private FileManagerForm FilesForm;
        public FormulaForm(FileManagerForm FilesForm)
        {
            InitializeComponent();
            this.FilesForm = FilesForm;
        }

        private void FormulaForm_Load(object sender, EventArgs e)
        {
            Random Random = new Random();
            string[] Lines = File.ReadAllLines(Ask);
            int Random_q = Random.Next(Lines.Length);
            string TargetLine = Lines[Random_q];
            string[] Exercises = TargetLine.Split(',');
            x = Exercises[0];
            Answer = Exercises[1];
            XTextBox.Text = x;
        }

        private void XLabel_Click(object sender, EventArgs e)
        {

        }

        private void AnswerLabel_Click(object sender, EventArgs e)
        {

        }

        private void XTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void AnswerTextBox_TextChanged(object sender, EventArgs e)
        {

        }
        private void AnswerButton_Click(object sender, EventArgs e)
        {
            if (AnswerTextBox.Text == Answer)
            {
                MessageBox.Show("Вірна відповідь.");
                FilesForm.Enabled = true;
                this.Close();
            }
            else
            {
                MessageBox.Show("Невірна відповідь.\nВихід з аккаунта!");
                FilesForm.Close();
                this.Close();
                Authorization AuthorizationForm = new Authorization();
                AuthorizationForm.Show();
            }
        }
    }
}
