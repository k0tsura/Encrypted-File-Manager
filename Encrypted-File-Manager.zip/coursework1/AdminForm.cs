﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace сoursework
{
    public partial class AdminForm : Form
    {
        private string Users = @"C:\Users\k0tsu\Desktop\coursework\nameuser.txt";

        public AdminForm()
        {
            InitializeComponent();
        }

        private void LoadUserData()
        {
            string[] Lines = File.ReadAllLines(Users);
            List<UserData> UserList = new List<UserData>();
            foreach (string Line in Lines)
            {
                string[] Parts = Line.Split(',');
                UserData UserData = new UserData
                {
                    Login = Parts[0].Trim(),
                    Password = Parts[1].Trim(),
                    LevelAccess = Parts[2].Trim(),
                };
                UserList.Add(UserData);
            }
            UsersListDataGridView.DataSource = UserList;
        }

        private void AdminForm_Load(object sender, EventArgs e)
        {
            LoadUserData();
        }

        private void UsersListDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void CreateButton_Click(object sender, EventArgs e)
        {
            this.Close();
            CreateUserForm CreateUser = new CreateUserForm();
            CreateUser.Show();
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            this.Close();
            DeleteUserForm DeleteUser = new DeleteUserForm();
            DeleteUser.Show();
        }

        private void RefreshButton_Click(object sender, EventArgs e)
        {
            UsersListDataGridView.DataSource = null;
            string[] Lines = File.ReadAllLines(Users);
            List<UserData> UserList = new List<UserData>();
            foreach (string Line in Lines)
            {
                string[] Parts = Line.Split(',');
                UserData UserData = new UserData
                {
                    Login = Parts[0].Trim(),
                    Password = Parts[1].Trim(),
                    LevelAccess = Parts[2].Trim(),
                };
                UserList.Add(UserData);
            }
            UsersListDataGridView.DataSource = UserList;
        }

        private void FileManagerButton_Click(object sender, EventArgs e)
        {
            this.Close();
            FileManagerForm FilesForm = new FileManagerForm();
            FilesForm.Show();
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
            Authorization Authorization = new Authorization();
            Authorization.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }

    public class UserData
    {
        public string Login { get; set; }
        public string Password { get; set; }
        public string LevelAccess { get; set; }
    }
}