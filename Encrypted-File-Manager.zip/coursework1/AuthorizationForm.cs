﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using static System.Windows.Forms.LinkLabel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace сoursework
{
    public partial class Authorization : Form
    {
        FileManagerForm FilesForm;
        private string Users = @"C:\Users\k0tsu\Desktop\coursework\nameuser.txt";
        private string Book = @"C:\Users\k0tsu\Desktop\coursework\us_book.txt";
        private string Logged = @"C:\Users\k0tsu\Desktop\coursework\logged.txt";

        public Authorization()
        {
            InitializeComponent();
        }

        private void AuthorizationForm_Load(object sender, EventArgs e)
        {

        }

        private void AuthorizationLabel_Click(object sender, EventArgs e)
        {

        }

        private void LoginLabel_Click(object sender, EventArgs e)
        {

        }
        private void PasswordLabel_Click(object sender, EventArgs e)
        {

        }

        private void LoginTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void PasswordTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        public int CheckerPowers(string Login, string Password)
        {
            using (StreamReader StreamReader = new StreamReader(Users))
            {
                string Line;
                while ((Line = StreamReader.ReadLine()) != null)
                {
                    string[] Powers = Line.Split(',');

                    if (Powers.Length == 3)
                    {
                        string SaveLogin = Powers[0];
                        string SavePassword = Powers[1];
                        string LevelAccess = Powers[2];
                        if (Login == SaveLogin && Password == SavePassword && LevelAccess != "3")
                        {
                            using (StreamWriter StreamWriter = new StreamWriter(Logged))
                            {
                                StreamWriter.Write("");
                                StreamWriter.Write(SaveLogin + "," + LevelAccess);
                            }
                            return 1;
                        }
                        else if (Login == SaveLogin && Password == SavePassword && LevelAccess == "3")
                        {
                            using (StreamWriter StreamWriter = new StreamWriter(Logged))
                            {
                                StreamWriter.Write("");
                                StreamWriter.Write(SaveLogin + "," + LevelAccess);
                            }
                            return -1;
                        }
                    }
                }
            }
            return 0;
        }

        private void EnterButton_Click(object sender, EventArgs e)
        {
            string Login = LoginTextBox.Text;
            string Password = PasswordTextBox.Text;
            LoginTextBox.Clear();
            PasswordTextBox.Clear();
            int Check = CheckerPowers(Login, Password);

            if (Check == 1)
            {
                using (StreamWriter StreamWriter = new StreamWriter(Book, true))
                {
                    using (StreamReader StreamReader = new StreamReader(Logged))
                    {
                        string Line = StreamReader.ReadLine();
                        string[] LoginUser = Line.Split(',');
                        string SavePassword = LoginUser[0];
                        string NewLine = (SavePassword + ", " + DateTime.Now + ", login");
                        StreamWriter.WriteLine(NewLine);
                    }
                }
                FilesForm = new FileManagerForm();
                FilesForm.Show();
                this.Hide();
            }
            else if (Check == -1)
            {
                using (StreamWriter StreamWriter = new StreamWriter(Book, true))
                {
                    using (StreamReader StreamReader = new StreamReader(Logged))
                    {
                        string Line = StreamReader.ReadLine();
                        string[] LoginUser = Line.Split(',');
                        string SavePassword = LoginUser[0];
                        string NewLine = (SavePassword + ", " + DateTime.Now + ", login");
                        StreamWriter.WriteLine(NewLine);
                    }
                    AdminForm AdminForm = new AdminForm();
                    AdminForm.Show();
                    this.Hide();
                }
            }
            else
            {
                MessageBox.Show("Невірний логін або пароль.");
            }
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}