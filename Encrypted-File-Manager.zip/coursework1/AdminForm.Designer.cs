﻿namespace сoursework
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.UsersListDataGridView = new System.Windows.Forms.DataGridView();
            this.CreateButton = new System.Windows.Forms.Button();
            this.DeleteButton = new System.Windows.Forms.Button();
            this.FileManagerButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.RefreshButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.UsersListDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // Users
            // 
            this.UsersListDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.UsersListDataGridView.Location = new System.Drawing.Point(12, 12);
            this.UsersListDataGridView.Name = "Users";
            this.UsersListDataGridView.Size = new System.Drawing.Size(400, 238);
            this.UsersListDataGridView.TabIndex = 0;
            this.UsersListDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.UsersListDataGridView_CellContentClick);
            // 
            // AddBtn
            // 
            this.CreateButton.Location = new System.Drawing.Point(12, 256);
            this.CreateButton.Name = "AddBtn";
            this.CreateButton.Size = new System.Drawing.Size(75, 25);
            this.CreateButton.TabIndex = 1;
            this.CreateButton.Text = "Створити";
            this.CreateButton.UseVisualStyleBackColor = true;
            this.CreateButton.Click += new System.EventHandler(this.CreateButton_Click);
            // 
            // DelBtn
            // 
            this.DeleteButton.Location = new System.Drawing.Point(93, 256);
            this.DeleteButton.Name = "DelBtn";
            this.DeleteButton.Size = new System.Drawing.Size(75, 25);
            this.DeleteButton.TabIndex = 2;
            this.DeleteButton.Text = "Видалити";
            this.DeleteButton.UseVisualStyleBackColor = true;
            this.DeleteButton.Click += new System.EventHandler(this.DeleteButton_Click);
            // 
            // FileBtn
            // 
            this.FileManagerButton.Location = new System.Drawing.Point(302, 256);
            this.FileManagerButton.Name = "FileBtn";
            this.FileManagerButton.Size = new System.Drawing.Size(110, 25);
            this.FileManagerButton.TabIndex = 3;
            this.FileManagerButton.Text = "Менеджер файлів";
            this.FileManagerButton.UseVisualStyleBackColor = true;
            this.FileManagerButton.Click += new System.EventHandler(this.FileManagerButton_Click);
            // 
            // LogOutBtn
            // 
            this.ExitButton.Location = new System.Drawing.Point(397, 324);
            this.ExitButton.Name = "LogOutBtn";
            this.ExitButton.Size = new System.Drawing.Size(75, 23);
            this.ExitButton.TabIndex = 4;
            this.ExitButton.Text = "Вихід";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // RefreshBtn
            // 
            this.RefreshButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.RefreshButton.Location = new System.Drawing.Point(423, 12);
            this.RefreshButton.Name = "RefreshBtn";
            this.RefreshButton.Size = new System.Drawing.Size(49, 40);
            this.RefreshButton.TabIndex = 6;
            this.RefreshButton.Text = "🔄";
            this.RefreshButton.UseVisualStyleBackColor = true;
            this.RefreshButton.Click += new System.EventHandler(this.RefreshButton_Click);
            // 
            // AdminForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 361);
            this.Controls.Add(this.RefreshButton);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.FileManagerButton);
            this.Controls.Add(this.DeleteButton);
            this.Controls.Add(this.CreateButton);
            this.Controls.Add(this.UsersListDataGridView);
            this.Name = "AdminForm";
            this.Text = "Адмін панель";
            this.Load += new System.EventHandler(this.AdminForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.UsersListDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView UsersListDataGridView;
        private System.Windows.Forms.Button CreateButton;
        private System.Windows.Forms.Button DeleteButton;
        private System.Windows.Forms.Button RefreshButton;
        private System.Windows.Forms.Button FileManagerButton;
        private System.Windows.Forms.Button ExitButton;
    }
}