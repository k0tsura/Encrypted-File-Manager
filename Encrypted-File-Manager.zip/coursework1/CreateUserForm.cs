﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace сoursework
{
    public partial class CreateUserForm : Form
    {
        string SelectedValue;
        private string Users = @"C:\Users\k0tsu\Desktop\coursework\nameuser.txt";

        public CreateUserForm()
        {
            InitializeComponent();
            InitializeComboBox();
        }
 
        private void InitializeComboBox()
        {
            LevelAccessComboBox.Items.Add("1");
            LevelAccessComboBox.Items.Add("2");
            LevelAccessComboBox.Items.Add("3");
            LevelAccessComboBox.SelectedIndex = 0;
            LevelAccessComboBox.SelectedIndexChanged += LevelAccessComboBox_SelectedIndexChanged;
        }

        private void CreateUser_Load(object sender, EventArgs e)
        {

        }

        private void LoginLabel_Click(object sender, EventArgs e)
        {

        }

        private void PasswordLabel_Click(object sender, EventArgs e)
        {

        }

        private void LevelAccessLabel_Click(object sender, EventArgs e)
        {

        }

        private void LoginTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void PasswordTextBos_TextChanged(object sender, EventArgs e)
        {

        }

        private void LevelAccessComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            SelectedValue = LevelAccessComboBox.SelectedItem.ToString();
        }

        private void CreateButton_Click(object sender, EventArgs e)
        {
            string Login = LoginTextBox.Text;
            string Password = PasswordTextBox.Text;
            string LevelAccess = SelectedValue;
            using (StreamWriter StreamWriter = new StreamWriter(Users, true))
            {
                string Line = (Login + "," + Password + "," + LevelAccess);
                StreamWriter.WriteLine(Line);
            }
            MessageBox.Show("Аккаунт створено.");
            this.Close();
            AdminForm AdminForm = new AdminForm();
            AdminForm.Show();
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
            AdminForm AdminForm = new AdminForm();
            AdminForm.Show();
        }
    }
}
