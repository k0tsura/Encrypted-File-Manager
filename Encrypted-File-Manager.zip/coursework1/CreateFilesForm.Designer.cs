﻿namespace сoursework
{
    partial class CreateForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CreateButton = new System.Windows.Forms.Button();
            this.CancelButton1 = new System.Windows.Forms.Button();
            this.CreateRichTextBox = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // CreateButton
            // 
            this.CreateButton.Location = new System.Drawing.Point(12, 326);
            this.CreateButton.Name = "CreateButton";
            this.CreateButton.Size = new System.Drawing.Size(75, 25);
            this.CreateButton.TabIndex = 0;
            this.CreateButton.Text = "Створити";
            this.CreateButton.UseVisualStyleBackColor = true;
            this.CreateButton.Click += new System.EventHandler(this.CreateButton_Click);
            // 
            // CancelButton
            // 
            this.CancelButton1.Location = new System.Drawing.Point(397, 324);
            this.CancelButton1.Name = "CancelButton";
            this.CancelButton1.Size = new System.Drawing.Size(75, 25);
            this.CancelButton1.TabIndex = 1;
            this.CancelButton1.Text = "Скасувати";
            this.CancelButton1.UseVisualStyleBackColor = true;
            this.CancelButton1.Click += new System.EventHandler(this.CancelButton_Click);
            // 
            // CreateRichTextBox
            // 
            this.CreateRichTextBox.Location = new System.Drawing.Point(12, 12);
            this.CreateRichTextBox.Name = "CreateRichTextBox";
            this.CreateRichTextBox.Size = new System.Drawing.Size(400, 238);
            this.CreateRichTextBox.TabIndex = 4;
            this.CreateRichTextBox.Text = "";
            this.CreateRichTextBox.TextChanged += new System.EventHandler(this.CreateRichTextBox_TextChanged);
            // 
            // CreateForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 361);
            this.Controls.Add(this.CreateRichTextBox);
            this.Controls.Add(this.CancelButton1);
            this.Controls.Add(this.CreateButton);
            this.Name = "CreateForm";
            this.Text = "Створення файлу";
            this.Load += new System.EventHandler(this.CreateFilesForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button CreateButton;
        private System.Windows.Forms.Button CancelButton1;
        private System.Windows.Forms.RichTextBox CreateRichTextBox;
    }
}