﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace сoursework
{
    public partial class DeleteUserForm : Form
    {
        private string Users = @"C:\Users\k0tsu\Desktop\coursework\nameuser.txt";
        public DeleteUserForm()
        {
            InitializeComponent();
        }

        private void DeleteUser_Load(object sender, EventArgs e)
        {

        }
        private void LoginLabel_Click(object sender, EventArgs e)
        {

        }

        private void PasswordLabel_Click(object sender, EventArgs e)
        {

        }

        private void LoginTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void PasswordTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            string[] Lines = File.ReadAllLines(Users);
            string Login = LoginTextBox.Text;
            string Password = PasswordTextBox.Text;
            List<string> List = new List<string>();
            using (StreamReader StreamReader = new StreamReader(Users))
            {
                string Line;
                while ((Line = StreamReader.ReadLine()) != null)
                {
                    string[] Powers = Line.Split(',');
                    string SavedLogin = Powers[0];
                    string SavedPassword = Powers[1];
                    if (!Line.Contains(Login) && !Line.Contains(Password))
                    {
                        List.Add(Line);
                    }
                }
            }
            File.WriteAllLines(Users, List);
            MessageBox.Show("Видалено.");
            this.Close();
            AdminForm AdminForm = new AdminForm();
            AdminForm.Show();
        }
        private void CancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
            AdminForm AdminForm = new AdminForm();
            AdminForm.Show();
        }
    }   
}
