﻿namespace сoursework
{
    partial class FormulaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AnswerButton = new System.Windows.Forms.Button();
            this.XTextBox = new System.Windows.Forms.TextBox();
            this.AnswerTextBox = new System.Windows.Forms.TextBox();
            this.XLabel = new System.Windows.Forms.Label();
            this.AnswerLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // CompareBtn
            // 
            this.AnswerButton.Location = new System.Drawing.Point(197, 226);
            this.AnswerButton.Name = "CompareBtn";
            this.AnswerButton.Size = new System.Drawing.Size(75, 23);
            this.AnswerButton.TabIndex = 0;
            this.AnswerButton.Text = "Відповісти";
            this.AnswerButton.UseVisualStyleBackColor = true;
            this.AnswerButton.Click += new System.EventHandler(this.AnswerButton_Click);
            // 
            // XTextBox
            // 
            this.XTextBox.Enabled = false;
            this.XTextBox.Location = new System.Drawing.Point(103, 6);
            this.XTextBox.Name = "XTextBox";
            this.XTextBox.Size = new System.Drawing.Size(100, 20);
            this.XTextBox.TabIndex = 1;
            this.XTextBox.TextChanged += new System.EventHandler(this.XTextBox_TextChanged);
            // 
            // AnswerTextBox
            // 
            this.AnswerTextBox.Location = new System.Drawing.Point(103, 32);
            this.AnswerTextBox.Name = "AnswerTextBox";
            this.AnswerTextBox.Size = new System.Drawing.Size(100, 20);
            this.AnswerTextBox.TabIndex = 2;
            this.AnswerTextBox.TextChanged += new System.EventHandler(this.AnswerTextBox_TextChanged);
            // 
            // XLbl
            // 
            this.XLabel.AutoSize = true;
            this.XLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.XLabel.Location = new System.Drawing.Point(76, 9);
            this.XLabel.Name = "XLbl";
            this.XLabel.Size = new System.Drawing.Size(21, 13);
            this.XLabel.TabIndex = 3;
            this.XLabel.Text = "x =";
            this.XLabel.Click += new System.EventHandler(this.XLabel_Click);
            // 
            // AnswLbl
            // 
            this.AnswerLabel.AutoSize = true;
            this.AnswerLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.AnswerLabel.Location = new System.Drawing.Point(33, 35);
            this.AnswerLabel.Name = "AnswLbl";
            this.AnswerLabel.Size = new System.Drawing.Size(64, 13);
            this.AnswerLabel.TabIndex = 4;
            this.AnswerLabel.Text = "4 * x^0,85 =";
            this.AnswerLabel.Click += new System.EventHandler(this.AnswerLabel_Click);
            // 
            // FormulaForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.AnswerLabel);
            this.Controls.Add(this.XLabel);
            this.Controls.Add(this.AnswerTextBox);
            this.Controls.Add(this.XTextBox);
            this.Controls.Add(this.AnswerButton);
            this.Name = "FormulaForm";
            this.Text = "Перевірка";
            this.Load += new System.EventHandler(this.FormulaForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label XLabel;
        private System.Windows.Forms.Label AnswerLabel;
        private System.Windows.Forms.TextBox XTextBox;
        private System.Windows.Forms.TextBox AnswerTextBox;
        private System.Windows.Forms.Button AnswerButton;
    }
}