﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace сoursework
{
    public partial class OpenForm : Form
    {
        private string Book = @"C:\Users\k0tsu\Desktop\coursework\us_book.txt";
        private string Logged = @"C:\Users\k0tsu\Desktop\coursework\logged.txt";
        private string Username;
        private FileManagerForm FileManagerForm;

        public OpenForm(FileManagerForm FileManagerForm)
        {
            InitializeComponent();
            using (StreamReader StreamReader = new StreamReader(Logged))
            {
                string Line = StreamReader.ReadLine();
                string[] Users = Line.Split(',');
                Username = Users[0];
            }

            this.FileManagerForm = FileManagerForm;
        }

        private string DecryptString(string cipherText, string key)
        {
            using (Aes AesAlgorithm = Aes.Create())
            {
                AesAlgorithm.Key = Encoding.UTF8.GetBytes(key);
                AesAlgorithm.IV = new byte[AesAlgorithm.BlockSize / 8];

                using (MemoryStream msDecrypt = new MemoryStream(Convert.FromBase64String(cipherText)))
                using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, AesAlgorithm.CreateDecryptor(), CryptoStreamMode.Read))
                using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                {
                    return srDecrypt.ReadToEnd();
                }
            }
        }

        private void ReadFilesForm_Load(object sender, EventArgs e)
        {
            string EncryptionKey = File.ReadAllText(@"C:\Users\k0tsu\Desktop\coursework\DESKey.txt");
            using (StreamReader StreamReader = new StreamReader(@"C:\Users\k0tsu\Desktop\coursework\foropen.txt"))
            {
                string EncryptedText = StreamReader.ReadToEnd();
                string DecryptedText = DecryptString(EncryptedText, EncryptionKey);
                ReadRichTextBox.Text = DecryptedText;
                using (StreamWriter StreamWriter = new StreamWriter(Book, true))
                {
                    StreamWriter.WriteLine(Username + ", " + DateTime.Now + ", Open file");
                }
            }
        }

        private void ReadRichTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            FileManagerForm.ShowHide();
            this.Close();
        }
    }
}
